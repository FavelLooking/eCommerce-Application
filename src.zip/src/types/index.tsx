export type LoginFormFields = {
  email: string;
  password: string;
};

export type RegExps = {
  regex: RegExp;
  error: string;
};
