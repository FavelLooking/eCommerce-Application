export type FlowType = 'password' | 'anonymous';
