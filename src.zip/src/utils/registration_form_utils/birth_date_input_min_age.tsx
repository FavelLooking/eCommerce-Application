const minAge = 13;

export default minAge;
